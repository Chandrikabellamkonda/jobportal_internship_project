from flask import Blueprint, render_template, request, flash
from app.models import Job, User, Application
from app import db

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    """Home page with featured jobs"""
    # Get latest jobs
    latest_jobs = Job.query.filter_by(is_active=True).order_by(Job.created_at.desc()).limit(6).all()
    
    # Get job statistics
    total_jobs = Job.query.filter_by(is_active=True).count()
    total_employers = User.query.filter_by(user_type='employer').count()
    total_job_seekers = User.query.filter_by(user_type='job_seeker').count()
    
    # Get popular categories
    from sqlalchemy import func
    popular_categories = db.session.query(
        Job.category, 
        func.count(Job.id).label('count')
    ).filter_by(is_active=True).group_by(Job.category).order_by(func.count(Job.id).desc()).limit(5).all()
    
    return render_template('main/home.html', 
                         latest_jobs=latest_jobs,
                         total_jobs=total_jobs,
                         total_employers=total_employers,
                         total_job_seekers=total_job_seekers,
                         popular_categories=popular_categories)

@main_bp.route('/search')
def search():
    """Job search page"""
    query = request.args.get('q', '').strip()
    location = request.args.get('location', '').strip()
    category = request.args.get('category', '').strip()
    job_type = request.args.get('job_type', '').strip()
    
    # Get all available categories and job types for filters
    categories = db.session.query(Job.category).filter_by(is_active=True).distinct().all()
    categories = [cat[0] for cat in categories]
    
    job_types = ['full_time', 'part_time', 'contract', 'internship']
    
    # Search jobs
    jobs_query = Job.search_jobs(query, location, category, job_type)
    jobs = jobs_query.paginate(
        page=request.args.get('page', 1, type=int),
        per_page=10,
        error_out=False
    )
    
    return render_template('main/search.html',
                         jobs=jobs,
                         query=query,
                         location=location,
                         category=category,
                         job_type=job_type,
                         categories=categories,
                         job_types=job_types)

@main_bp.route('/job/<int:job_id>')
def job_detail(job_id):
    """Job detail page"""
    job = Job.query.get_or_404(job_id)
    
    if not job.is_active:
        flash('This job posting is no longer available.', 'error')
        return redirect(url_for('main.home'))
    
    # Get related jobs from same company or category
    related_jobs = Job.query.filter(
        Job.id != job.id,
        Job.is_active == True,
        db.or_(
            Job.company_name == job.company_name,
            Job.category == job.category
        )
    ).limit(4).all()
    
    return render_template('main/job_detail.html', job=job, related_jobs=related_jobs)

@main_bp.route('/about')
def about():
    """About page"""
    return render_template('main/about.html')

@main_bp.route('/contact')
def contact():
    """Contact page"""
    return render_template('main/contact.html')
