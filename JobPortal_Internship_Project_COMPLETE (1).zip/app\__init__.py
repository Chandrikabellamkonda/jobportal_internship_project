from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
import os
import logging

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
migrate = Migrate()

def create_app():
    """Application factory pattern"""
    app = Flask(__name__)
    
    # Configure logging
    logging.basicConfig(level=logging.DEBUG)
    app.logger.setLevel(logging.DEBUG)
    
    # Configuration
    app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///job_portal.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Log configuration
    app.logger.info("Flask app created")
    app.logger.info(f"Database URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)
    migrate.init_app(app, db)
    
    # Login manager configuration
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    
    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.jobs import jobs_bp
    from app.routes.admin import admin_bp
    
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(main_bp)
    app.register_blueprint(jobs_bp, url_prefix='/jobs')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    # User loader for Flask-Login (must be outside app_context)
    from app.models import User
    
    @login_manager.user_loader
    def load_user(user_id):
        app.logger.debug(f"Loading user with ID: {user_id}")
        user = User.query.get(int(user_id))
        # Check if user exists and is active
        if user:
            user_is_active = getattr(user, 'is_active', True)  # Default to True if field doesn't exist
            if not user_is_active:
                app.logger.warning(f"Inactive user attempted to load: {user_id}")
                return None
        return user
    
    # Create tables and default admin
    with app.app_context():
        app.logger.info("Creating database tables...")
        db.create_all()
        app.logger.info("Database tables created successfully")
        
        # Handle migration for is_active field (for existing databases)
        # This must be done before any User model queries
        try:
            import sqlite3
            from pathlib import Path
            
            # Get database path
            db_path = app.config.get('DATABASE_URL', '').replace('sqlite:///', '')
            if not db_path:
                db_path = 'instance/job_portal.db'
            
            # Use direct SQLite connection to add column if it doesn't exist
            if Path(db_path).exists():
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Check if is_active column exists
                cursor.execute("PRAGMA table_info(users)")
                columns = [row[1] for row in cursor.fetchall()]
                
                if 'is_active' not in columns:
                    app.logger.info("Adding is_active column to users table...")
                    cursor.execute("ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT 1")
                    
                    # Update existing users to have is_active=True
                    cursor.execute("UPDATE users SET is_active = 1 WHERE is_active IS NULL")
                    conn.commit()
                    app.logger.info("Migration completed: Added is_active column")
                else:
                    app.logger.info("is_active column already exists")
                
                conn.close()
                
        except Exception as e:
            app.logger.error(f"Migration error: {e}")
            # If migration fails, continue - the app should still work
        
        # Check if admin exists, if not create one (after migration)
        try:
            admin = User.query.filter_by(email='admin@jobportal.com').first()
        except Exception as e:
            app.logger.error(f"Error querying admin user: {e}")
            admin = None
        if not admin:
            app.logger.info("Creating default admin user...")
            admin = User(
                email='admin@jobportal.com',
                full_name='System Administrator',
                user_type='admin',
                location='Global'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            app.logger.info("Default admin created: admin@jobportal.com / admin123")
        else:
            app.logger.info("Admin user already exists")
        
        # Log database status
        users = User.query.all()
        app.logger.info(f"Database initialized with {len(users)} users")
    
    return app
