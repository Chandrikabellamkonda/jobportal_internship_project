from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from app import db
from app.models import User, Job, Application

admin_bp = Blueprint('admin', __name__)

@admin_bp.before_request
def require_admin():
    """Require admin privileges for all admin routes"""
    if not current_user.is_authenticated or not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('main.home'))

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    """Admin dashboard with statistics"""
    # Get statistics
    total_users = User.query.count()
    total_jobs = Job.query.count()
    total_applications = Application.query.count()
    active_jobs = Job.query.filter_by(is_active=True).count()
    
    # Get user breakdown
    job_seekers = User.query.filter_by(user_type='job_seeker').count()
    employers = User.query.filter_by(user_type='employer').count()
    admins = User.query.filter_by(user_type='admin').count()
    
    # Get recent activity
    recent_jobs = Job.query.order_by(Job.created_at.desc()).limit(5).all()
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    # Get popular categories
    from sqlalchemy import func
    popular_categories = db.session.query(
        Job.category, 
        func.count(Job.id).label('count')
    ).filter_by(is_active=True).group_by(Job.category).order_by(func.count(Job.id).desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                         total_users=total_users,
                         total_jobs=total_jobs,
                         total_applications=total_applications,
                         active_jobs=active_jobs,
                         job_seekers=job_seekers,
                         employers=employers,
                         admins=admins,
                         recent_jobs=recent_jobs,
                         recent_users=recent_users,
                         popular_categories=popular_categories)

@admin_bp.route('/users')
@login_required
def manage_users():
    """Manage all users"""
    page = request.args.get('page', 1, type=int)
    user_type = request.args.get('type', '').strip()
    status = request.args.get('status', '').strip()
    
    query = User.query
    if user_type:
        query = query.filter_by(user_type=user_type)
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)
    
    users = query.order_by(User.created_at.desc()).paginate(
        page=page,
        per_page=20,
        error_out=False
    )
    
    return render_template('admin/users.html', users=users, user_type=user_type, status=status)

@admin_bp.route('/users/<int:user_id>/toggle-status')
@login_required
def toggle_user_status(user_id):
    """Toggle user active status"""
    user = User.query.get_or_404(user_id)
    
    # Don't allow admins to deactivate themselves or other admins
    if user.is_admin:
        flash('Cannot deactivate admin accounts.', 'error')
        return redirect(url_for('admin.manage_users'))
    
    try:
        user.is_active = not user.is_active
        status = "activated" if user.is_active else "deactivated"
        db.session.commit()
        flash(f'User {user.full_name} has been {status} successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while updating user status.', 'error')
    
    return redirect(url_for('admin.manage_users'))

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@login_required
def delete_user(user_id):
    """Delete a user (non-admin only)"""
    user = User.query.get_or_404(user_id)
    
    # Don't allow deletion of admin accounts
    if user.is_admin:
        flash('Cannot delete admin accounts.', 'error')
        return redirect(url_for('admin.manage_users'))
    
    # Don't allow deleting yourself
    if user.id == current_user.id:
        flash('Cannot delete your own account.', 'error')
        return redirect(url_for('admin.manage_users'))
    
    try:
        # Store user info before deletion for flash message
        user_name = user.full_name
        
        # Delete related data first (this should cascade automatically due to relationships)
        db.session.delete(user)
        db.session.commit()
        flash(f'User {user_name} has been deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while deleting the user.', 'error')
    
    return redirect(url_for('admin.manage_users'))

@admin_bp.route('/jobs')
@login_required
def manage_jobs():
    """Manage all jobs"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '').strip()
    
    query = Job.query
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)
    
    jobs = query.order_by(Job.created_at.desc()).paginate(
        page=page,
        per_page=20,
        error_out=False
    )
    
    return render_template('admin/jobs.html', jobs=jobs, status=status)

@admin_bp.route('/jobs/<int:job_id>/toggle-status')
@login_required
def toggle_job_status(job_id):
    """Toggle job active status"""
    job = Job.query.get_or_404(job_id)
    
    job.is_active = not job.is_active
    status = "activated" if job.is_active else "deactivated"
    
    try:
        db.session.commit()
        flash(f'Job "{job.title}" {status} successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while updating the job status.', 'error')
    
    return redirect(url_for('admin.manage_jobs'))

@admin_bp.route('/jobs/<int:job_id>/delete')
@login_required
def delete_job(job_id):
    """Delete a job"""
    job = Job.query.get_or_404(job_id)
    
    try:
        db.session.delete(job)
        db.session.commit()
        flash(f'Job "{job.title}" deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while deleting the job.', 'error')
    
    return redirect(url_for('admin.manage_jobs'))

@admin_bp.route('/applications')
@login_required
def manage_applications():
    """Manage all applications"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '').strip()
    
    query = Application.query
    if status:
        query = query.filter_by(status=status)
    
    applications = query.order_by(Application.applied_at.desc()).paginate(
        page=page,
        per_page=20,
        error_out=False
    )
    
    return render_template('admin/applications.html', applications=applications, status=status)

@admin_bp.route('/settings')
@login_required
def settings():
    """Admin settings"""
    return render_template('admin/settings.html')
