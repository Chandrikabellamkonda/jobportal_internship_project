# Job Portal Web Application - Technical Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Technology Stack](#technology-stack)
3. [Architecture & Design Patterns](#architecture--design-patterns)
4. [Database Design](#database-design)
5. [Application Structure](#application-structure)
6. [Core Features Implementation](#core-features-implementation)
7. [Security Features](#security-features)
8. [File Upload System](#file-upload-system)
9. [User Management System](#user-management-system)
10. [API Routes & Endpoints](#api-routes--endpoints)
11. [Frontend Implementation](#frontend-implementation)
12. [Database Migrations](#database-migrations)
13. [Error Handling & Logging](#error-handling--logging)
14. [Testing & Sample Data](#testing--sample-data)
15. [Deployment Considerations](#deployment-considerations)

---

## 1. Project Overview

The Job Portal Web Application is a full-stack web application built for managing job postings, applications, and user interactions between job seekers and employers. The application follows modern web development practices and implements a secure, scalable architecture.

### Key Business Requirements:
- **User Registration & Authentication**: Support for Job Seekers, Employers, and Admins
- **Job Management**: Post, edit, search, and manage job listings
- **Application System**: Apply for jobs with resume uploads and cover letters
- **Admin Panel**: Complete administrative control over users, jobs, and applications
- **File Management**: Secure resume upload and download system

---

## 2. Technology Stack

### Backend Framework
- **Flask 2.3.3**: Lightweight Python web framework
- **Python 3.12**: Programming language

### Database & ORM
- **SQLite**: Relational database for development
- **SQLAlchemy 2.0.21**: Python ORM for database operations
- **Flask-SQLAlchemy 3.0.5**: Flask integration for SQLAlchemy

### Authentication & Security
- **Flask-Login 0.6.3**: User session management
- **Flask-Bcrypt 1.0.1**: Password hashing and security
- **Werkzeug 2.3.7**: WSGI utilities and security features

### Database Migrations
- **Flask-Migrate 4.0.5**: Database schema migrations

### Frontend Technologies
- **HTML5**: Semantic markup
- **CSS3**: Styling and responsive design
- **Bootstrap 5**: CSS framework for responsive UI
- **JavaScript**: Client-side functionality
- **Jinja2**: Template engine (Flask default)

### Additional Libraries
- **bcrypt 4.0.1**: Password hashing
- **python-dotenv 1.0.0**: Environment variable management
- **gunicorn 21.2.0**: WSGI HTTP Server for production

---

## 3. Architecture & Design Patterns

### Application Factory Pattern
The application uses Flask's Application Factory pattern for better modularity and testing:

```python
def create_app():
    """Application factory pattern"""
    app = Flask(__name__)
    # Configuration and initialization
    return app
```

### Blueprint Architecture
The application is organized using Flask Blueprints for modular routing:

- **`auth_bp`**: Authentication routes (`/auth`)
- **`main_bp`**: Main application routes (`/`)
- **`jobs_bp`**: Job-related routes (`/jobs`)
- **`admin_bp`**: Administrative routes (`/admin`)

### MVC Pattern
- **Models**: `app/models.py` (User, Job, Application)
- **Views**: Template files in `app/templates/`
- **Controllers**: Route functions in `app/routes/`

---

## 4. Database Design

### Database Schema

#### Users Table (`users`)
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    user_type ENUM('job_seeker', 'employer', 'admin') NOT NULL,
    company_name VARCHAR(100),
    phone VARCHAR(20),
    location VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### Jobs Table (`jobs`)
```sql
CREATE TABLE jobs (
    id INTEGER PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    company_name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    salary_min INTEGER,
    salary_max INTEGER,
    job_type ENUM('full_time', 'part_time', 'contract', 'internship') NOT NULL,
    category VARCHAR(50) NOT NULL,
    requirements TEXT,
    benefits TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    employer_id INTEGER NOT NULL,
    FOREIGN KEY (employer_id) REFERENCES users(id)
);
```

#### Applications Table (`applications`)
```sql
CREATE TABLE applications (
    id INTEGER PRIMARY KEY,
    cover_letter TEXT,
    resume_filename VARCHAR(255),
    status ENUM('pending', 'reviewed', 'accepted', 'rejected') DEFAULT 'pending',
    applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME,
    job_id INTEGER NOT NULL,
    applicant_id INTEGER NOT NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id),
    FOREIGN KEY (applicant_id) REFERENCES users(id)
);
```

### Relationships
- **User → Jobs**: One-to-Many (Employers can post multiple jobs)
- **User → Applications**: One-to-Many (Users can apply to multiple jobs)
- **Job → Applications**: One-to-Many (Jobs can have multiple applications)
- **User → User**: Self-referential for employer-applicant relationships

---

## 5. Application Structure

```
app/
├── __init__.py              # Application factory and configuration
├── models.py                # Database models (User, Job, Application)
├── routes/
│   ├── auth.py             # Authentication routes
│   ├── main.py             # Main application routes
│   ├── jobs.py             # Job management routes
│   └── admin.py            # Administrative routes
├── templates/              # Jinja2 templates
│   ├── base.html           # Base template
│   ├── auth/               # Authentication templates
│   ├── main/               # Main page templates
│   ├── jobs/               # Job-related templates
│   └── admin/              # Admin panel templates
├── static/
│   ├── css/                # Stylesheets
│   └── js/                 # JavaScript files
└── utils/
    └── validators.py       # Input validation utilities
```

---

## 6. Core Features Implementation

### 6.1 User Authentication System

#### User Registration (`auth.py:register()`)
```python
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration with comprehensive validation"""
    
    # Input validation using custom validators
    if not validate_email(email):
        errors.append('Please enter a valid email address.')
    
    if not validate_password(password):
        errors.append('Password must be at least 8 characters long.')
    
    # Password hashing using bcrypt
    user.set_password(password)  # Calls bcrypt.generate_password_hash()
```

#### User Login (`auth.py:login()`)
```python
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Secure login with active user validation"""
    
    # Check user account status
    user_is_active = getattr(user, 'is_active', True)
    if not user_is_active:
        flash('Your account has been deactivated...', 'error')
        return render_template('auth/login.html')
    
    # Password verification
    if user.check_password(password):  # Calls bcrypt.check_password_hash()
        login_user(user, remember=remember)
```

#### Session Management
- **Flask-Login** handles user sessions
- **Remember Me** functionality for persistent sessions
- **Automatic logout** for inactive users
- **Session-based role-based access control**

### 6.2 Job Management System

#### Job Posting (`jobs.py:post_job()`)
```python
@jobs_bp.route('/post', methods=['GET', 'POST'])
def post_job():
    """Job posting with comprehensive validation"""
    
    # Input validation
    if not validate_user_input(description, min_length=20, max_length=5000):
        errors.append('Job description must be 20-5000 characters.')
    
    # Salary validation
    if salary_min and salary_max and salary_min > salary_max:
        errors.append('Minimum salary cannot be greater than maximum.')
```

#### Job Search Implementation (`models.py:Job.search_jobs()`)
```python
@staticmethod
def search_jobs(query, location=None, category=None, job_type=None):
    """Advanced job search with multiple filters"""
    jobs = Job.query.filter(Job.is_active == True)
    
    if query:
        jobs = jobs.filter(
            db.or_(
                Job.title.contains(query),
                Job.description.contains(query),
                Job.company_name.contains(query)
            )
        )
    
    # Additional filters for location, category, job_type
    return jobs.order_by(Job.created_at.desc())
```

### 6.3 Application Management System

#### Job Application (`jobs.py:apply_job()`)
```python
@jobs_bp.route('/apply/<int:job_id>', methods=['GET', 'POST'])
def apply_job(job_id):
    """Job application with file upload and validation"""
    
    # Resume file validation
    if file_size > MAX_FILE_SIZE:
        flash('Resume file is too large. Maximum size is 5MB.', 'error')
    
    if not allowed_file(resume_file.filename):
        flash('Invalid file format. Please upload PDF, DOC, or DOCX.', 'error')
    
    # Save file with unique naming
    resume_filename = save_resume(resume_file, user_id, job_id)
```

#### Application Status Management
- **Four Status Levels**: pending, reviewed, accepted, rejected
- **Timestamp Tracking**: applied_at, reviewed_at
- **Status Update Permissions**: Employers and Admins only

---

## 7. Security Features

### 7.1 Password Security
```python
def set_password(self, password):
    """Hash password using bcrypt"""
    self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

def check_password(self, password):
    """Verify password against hash"""
    return bcrypt.check_password_hash(self.password_hash, password)
```

### 7.2 User Access Control
```python
@admin_bp.before_request
def require_admin():
    """Global admin access control"""
    if not current_user.is_authenticated or not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('main.home'))
```

### 7.3 Input Validation & Sanitization
```python
def validate_user_input(input_value, min_length=1, max_length=255):
    """Comprehensive input validation"""
    if not input_value or not isinstance(input_value, str):
        return False
    
    # Length validation
    if len(input_value.strip()) < min_length or len(input_value) > max_length:
        return False
    
    # Character validation
    pattern = r'^[a-zA-Z0-9\s.,!?@#$%&*()_+-=:;<>\[\]{}|\\/"\'`~]+$'
    return bool(re.match(pattern, input_value))
```

### 7.4 File Upload Security
```python
def allowed_file(filename):
    """Validate file extensions"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_resume(file, user_id, job_id):
    """Secure file saving with unique naming"""
    file_extension = file.filename.rsplit('.', 1)[1].lower()
    unique_filename = f"{user_id}_{job_id}_{uuid.uuid4().hex}.{file_extension}"
```

---

## 8. File Upload System

### 8.1 Configuration
```python
UPLOAD_FOLDER = 'uploads/resumes'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
```

### 8.2 File Handling Process
1. **Validation**: Check file extension and size
2. **Security**: Generate unique filename to prevent conflicts
3. **Storage**: Save to dedicated directory
4. **Database**: Store filename reference in Application model
5. **Access Control**: Restrict download access based on user roles

### 8.3 File Download Security
```python
@jobs_bp.route('/resume/<int:application_id>', methods=['GET'])
def download_resume(application_id):
    """Secure file download with permission checking"""
    
    # Permission validation
    if not (current_user.is_admin or 
            (current_user.is_employer and application.job.employer_id == current_user.id) or
            (current_user.is_job_seeker and application.applicant_id == current_user.id)):
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    return send_from_directory(upload_path, filename, as_attachment=True)
```

---

## 9. User Management System

### 9.1 User Types & Roles
- **Job Seeker**: Can apply for jobs, manage applications
- **Employer**: Can post jobs, manage applications received
- **Admin**: Full system access, user management

### 9.2 User Status Management
```python
# Add is_active field to User model
is_active = db.Column(db.Boolean, default=True, nullable=False)

# Toggle user status
def toggle_user_status(user_id):
    """Toggle user active/inactive status"""
    user.is_active = not user.is_active
    # Inactive users cannot log in
```

### 9.3 Admin User Management Features
- **User List**: Paginated user listing with filters
- **Status Toggle**: Activate/deactivate user accounts
- **User Deletion**: Delete non-admin users with safety checks
- **User Profile View**: Detailed user information modal

---

## 10. API Routes & Endpoints

### 10.1 Authentication Routes (`/auth`)
```
GET  /auth/register          # Registration form
POST /auth/register          # Process registration
GET  /auth/login             # Login form
POST /auth/login             # Process login
GET  /auth/logout            # User logout
GET  /auth/profile           # User profile page
```

### 10.2 Main Application Routes (`/`)
```
GET  /                       # Home page with job listings
GET  /search                 # Job search with filters
GET  /job/<id>               # Job detail page
GET  /about                  # About page
GET  /contact                # Contact page
```

### 10.3 Job Management Routes (`/jobs`)
```
GET  /jobs/                  # Employer's job listings
GET  /jobs/post              # Post job form
POST /jobs/post              # Process job posting
GET  /jobs/edit/<id>         # Edit job form
POST /jobs/edit/<id>         # Update job
GET  /jobs/delete/<id>       # Delete job
GET  /jobs/toggle/<id>       # Toggle job status
GET  /jobs/apply/<id>        # Application form
POST /jobs/apply/<id>        # Submit application
GET  /jobs/applications      # View applications
POST /jobs/application/<id>/update-status  # Update application status
GET  /jobs/application/<id>  # View application details
GET  /jobs/resume/<id>       # Download resume
```

### 10.4 Admin Routes (`/admin`)
```
GET  /admin/dashboard        # Admin dashboard
GET  /admin/users            # User management
POST /admin/users/<id>/toggle-status  # Toggle user status
POST /admin/users/<id>/delete         # Delete user
GET  /admin/jobs             # Job management
GET  /admin/applications     # Application management
GET  /admin/settings         # System settings
```

---

## 11. Frontend Implementation

### 11.1 Template Structure
```
base.html                    # Base template with navigation
├── auth/
│   ├── login.html          # Login form
│   ├── register.html       # Registration form
│   └── profile.html        # User profile
├── main/
│   ├── home.html           # Landing page
│   ├── search.html         # Job search results
│   ├── job_detail.html     # Job details
│   ├── about.html          # About page
│   └── contact.html        # Contact form
├── jobs/
│   ├── post_job.html       # Job posting form
│   ├── apply_job.html      # Application form
│   ├── my_jobs.html        # Employer job list
│   ├── my_applications.html # User applications
│   └── application_details.html # Application details
└── admin/
    ├── dashboard.html      # Admin dashboard
    ├── users.html          # User management
    ├── jobs.html           # Job management
    └── applications.html   # Application management
```

### 11.2 Responsive Design
- **Bootstrap 5** for responsive grid system
- **Mobile-first** approach
- **Consistent navigation** across all pages
- **Form validation** with user feedback

### 11.3 JavaScript Functionality
```javascript
// Button loading states
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
            if (submitBtn) {
                showButtonLoading(submitBtn);
            }
        });
    });
});
```

---

## 12. Database Migrations

### 12.1 Migration System
```python
# Automatic migration for new fields
def handle_migration():
    try:
        # Check if is_active column exists
        cursor.execute("PRAGMA table_info(users)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'is_active' not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT 1")
            cursor.execute("UPDATE users SET is_active = 1 WHERE is_active IS NULL")
            conn.commit()
    except Exception as e:
        app.logger.error(f"Migration error: {e}")
```

### 12.2 Database Initialization
```python
def create_app():
    with app.app_context():
        db.create_all()  # Create all tables
        
        # Create default admin user
        admin = User.query.filter_by(email='admin@jobportal.com').first()
        if not admin:
            admin = User(
                email='admin@jobportal.com',
                full_name='System Administrator',
                user_type='admin',
                location='Global'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
```

---

## 13. Error Handling & Logging

### 13.1 Logging Configuration
```python
# Configure logging
logging.basicConfig(level=logging.DEBUG)
app.logger.setLevel(logging.DEBUG)
```

### 13.2 Error Handling Patterns
```python
try:
    # Database operations
    db.session.commit()
    flash('Operation successful!', 'success')
except Exception as e:
    db.session.rollback()
    current_app.logger.error(f"Error occurred: {e}")
    flash('An error occurred. Please try again.', 'error')
```

### 13.3 User-Friendly Error Messages
- **Form validation errors** with specific field feedback
- **Database constraint errors** with user-friendly messages
- **File upload errors** with size and format guidance
- **Access denied messages** with appropriate redirects

---

## 14. Testing & Sample Data

### 14.1 Sample Data Script (`create_sample_data.py`)
```python
def create_sample_data():
    """Create sample users and jobs for testing"""
    
    # Create sample job seeker
    job_seeker = User(
        email='jobseeker@example.com',
        full_name='John Doe',
        user_type='job_seeker',
        location='New York, NY'
    )
    job_seeker.set_password('password123')
    
    # Create sample employer
    employer = User(
        email='employer@example.com',
        full_name='Jane Smith',
        user_type='employer',
        company_name='Tech Corp'
    )
    employer.set_password('password123')
```

### 14.2 Default Accounts
- **Admin**: `admin@jobportal.com` / `admin123`
- **Job Seeker**: `jobseeker@example.com` / `password123`
- **Employer**: `employer@example.com` / `password123`

---

## 15. Deployment Considerations

### 15.1 Production Configuration
```python
# Production settings needed
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
```

### 15.2 Security Considerations
- **Environment Variables**: Store sensitive data in environment variables
- **HTTPS**: Use SSL certificates in production
- **File Upload Limits**: Configure web server upload limits
- **Database**: Consider PostgreSQL for production scalability

### 15.3 Performance Optimizations
- **Database Indexing**: Email and foreign key indexes implemented
- **Pagination**: Implemented for large data sets
- **File Storage**: Consider cloud storage for resume files
- **Caching**: Implement Redis for session and data caching

---

## Technical Interview Questions & Answers

### Q1: How did you implement user authentication and security?

**Answer**: I implemented a comprehensive authentication system using Flask-Login and Flask-Bcrypt. Passwords are hashed using bcrypt before storage, and I added an `is_active` field to prevent deactivated users from logging in. The system includes session management, role-based access control, and secure password validation.

### Q2: How does the file upload system work?

**Answer**: The resume upload system includes multiple security layers: file extension validation (PDF, DOC, DOCX), file size limits (5MB), unique filename generation using UUID to prevent conflicts, and access control that only allows authorized users (employers, admins, or the applicant) to download files.

### Q3: How did you handle database relationships and queries?

**Answer**: I used SQLAlchemy ORM with proper foreign key relationships. The application has three main models - User, Job, and Application - with one-to-many relationships. I implemented a search function that uses SQLAlchemy's query builder with filters for text search, location, category, and job type.

### Q4: What design patterns did you use?

**Answer**: I implemented the Application Factory pattern for Flask initialization, Blueprint architecture for modular routing, and MVC pattern for separation of concerns. The code is organized into logical modules with clear separation between models, views, and controllers.

### Q5: How did you handle user permissions and access control?

**Answer**: I implemented role-based access control with three user types (job_seeker, employer, admin) and used Flask-Login decorators like `@login_required` and custom permission checks. Each route validates user permissions before allowing access to functionality.

This technical documentation provides comprehensive coverage of all aspects of the Job Portal application, ensuring you can confidently answer any questions during your internship presentation.
