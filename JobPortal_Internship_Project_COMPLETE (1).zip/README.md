# Job Portal Web Application

A comprehensive job portal web application built with Flask that allows users to post job listings, search for jobs, and apply for positions. This application supports three types of users: Job Seekers, Employers, and Administrators.

## Features

### For Job Seekers
- User registration and login
- Search and filter job listings
- Apply for jobs with cover letter
- View application status
- Manage profile information

### For Employers
- User registration and login
- Post new job listings
- Manage existing job postings
- View and manage job applications
- Toggle job status (active/inactive)

### For Administrators
- Manage all users and jobs
- View application statistics
- Oversee platform operations
- Access admin dashboard

### Core Features
- Responsive design with Bootstrap 5
- Secure user authentication
- Job search with filters (location, category, job type)
- Real-time application tracking
- Clean and modern UI/UX
- Database management with SQLite

## Tech Stack

- **Backend:** Python with Flask framework
- **Frontend:** HTML, CSS, Bootstrap 5, JavaScript
- **Database:** SQLite (easily upgradeable to PostgreSQL)
- **Authentication:** Flask-Login with password hashing
- **Styling:** Custom CSS with Bootstrap components

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Step 1: Clone or Download
```bash
# If using git
git clone <repository-url>
cd "Job Portal Web app"

# Or simply download and extract the project files
```

### Step 2: Create Virtual Environment
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Initialize Database
```bash
# Run the application to create database
python run.py
```

### Step 5: Create Sample Data (Optional)
```bash
# Create sample data for testing
python create_sample_data.py
```

### Step 6: Run the Application
```bash
python run.py
```

The application will be available at `http://localhost:5000`

### Default Admin Account
A default admin account is automatically created:
- **Email:** admin@jobportal.com
- **Password:** admin123

## Usage

### Getting Started

1. **Register an Account**
   - Visit the homepage
   - Click "Register" in the navigation
   - Choose your role (Job Seeker or Employer)
   - Fill in the required information

2. **For Job Seekers**
   - Search for jobs using keywords, location, or filters
   - Click on job listings to view details
   - Apply for jobs with a cover letter
   - Track your applications in "My Applications"

3. **For Employers**
   - Post new job listings with detailed descriptions
   - Manage your job postings in "My Jobs"
   - Review and manage applications
   - Update job status as needed

4. **For Administrators**
   - Access the admin dashboard
   - Manage all users and job listings
   - View platform statistics
   - Monitor application activity

## Project Structure

```
Job Portal Web app/
├── app/
│   ├── __init__.py          # Flask app factory
│   ├── models.py            # Database models
│   ├── routes/
│   │   ├── auth.py          # Authentication routes
│   │   ├── main.py          # Main application routes
│   │   ├── jobs.py          # Job-related routes
│   │   └── admin.py         # Admin routes
│   ├── templates/
│   │   ├── base.html        # Base template
│   │   ├── auth/            # Authentication templates
│   │   ├── main/            # Main page templates
│   │   ├── jobs/            # Job-related templates
│   │   └── admin/           # Admin templates
│   ├── static/
│   │   ├── css/
│   │   │   └── style.css    # Custom CSS
│   │   └── js/
│   │       └── main.js      # Custom JavaScript
│   └── utils/
│       └── validators.py    # Input validation utilities
├── run.py                   # Application entry point
├── requirements.txt         # Python dependencies
├── README.md               # This file
└── job_portal.db          # SQLite database (created after first run)
```

## Database Schema

### Users Table
- `id` - Primary key
- `email` - Unique email address
- `password_hash` - Hashed password
- `full_name` - User's full name
- `user_type` - 'job_seeker', 'employer', or 'admin'
- `company_name` - Company name (for employers)
- `phone` - Phone number
- `location` - User location
- `created_at` - Account creation timestamp
- `updated_at` - Last update timestamp

### Jobs Table
- `id` - Primary key
- `title` - Job title
- `description` - Job description
- `company_name` - Company name
- `location` - Job location
- `salary_min` - Minimum salary
- `salary_max` - Maximum salary
- `job_type` - 'full_time', 'part_time', 'contract', 'internship'
- `category` - Job category
- `requirements` - Job requirements
- `benefits` - Job benefits
- `is_active` - Job status
- `employer_id` - Foreign key to users table
- `created_at` - Job posting timestamp
- `updated_at` - Last update timestamp

### Applications Table
- `id` - Primary key
- `cover_letter` - Cover letter text
- `resume_filename` - Resume file name (future feature)
- `status` - 'pending', 'reviewed', 'accepted', 'rejected'
- `applied_at` - Application timestamp
- `reviewed_at` - Review timestamp
- `job_id` - Foreign key to jobs table
- `applicant_id` - Foreign key to users table

## API Endpoints

### Authentication
- `GET /auth/login` - Login page
- `POST /auth/login` - Process login
- `GET /auth/register` - Registration page
- `POST /auth/register` - Process registration
- `GET /auth/logout` - Logout user
- `GET /auth/profile` - User profile

### Main Application
- `GET /` - Homepage
- `GET /search` - Job search page
- `GET /job/<id>` - Job details
- `GET /about` - About page
- `GET /contact` - Contact page

### Job Management
- `GET /jobs/` - User's jobs (employers)
- `GET /jobs/post` - Post new job
- `POST /jobs/post` - Process job posting
- `GET /jobs/edit/<id>` - Edit job
- `POST /jobs/edit/<id>` - Process job edit
- `GET /jobs/delete/<id>` - Delete job
- `GET /jobs/toggle/<id>` - Toggle job status
- `GET /jobs/apply/<id>` - Apply for job
- `POST /jobs/apply/<id>` - Process application
- `GET /jobs/applications` - View applications

### Admin Panel
- `GET /admin/dashboard` - Admin dashboard
- `GET /admin/users` - Manage users
- `GET /admin/jobs` - Manage jobs
- `GET /admin/applications` - Manage applications
- `GET /admin/settings` - Admin settings

## Security Features

- Password hashing using bcrypt
- Session-based authentication
- Input validation and sanitization
- CSRF protection (Flask-WTF recommended for production)
- SQL injection prevention through SQLAlchemy ORM

## Deployment

### Local Development
```bash
python run.py
```

### Production Deployment
For production deployment, consider:

1. **Environment Variables**
   - Set `FLASK_ENV=production`
   - Use environment variables for secret keys
   - Configure proper database URLs

2. **Web Server**
   - Use Gunicorn or similar WSGI server
   - Configure reverse proxy (Nginx)

3. **Database**
   - Migrate to PostgreSQL for production
   - Set up proper database backups

4. **Security**
   - Use HTTPS
   - Configure proper CORS settings
   - Implement rate limiting

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is created for educational purposes as part of an internship program.

## Support

For support or questions, please contact the development team.

## Future Enhancements

- Resume upload functionality
- Email notifications
- Advanced search filters
- Company profiles
- Job recommendation system
- API for mobile applications
- Real-time chat between employers and applicants
- Advanced analytics dashboard
- Multi-language support
- Social media integration

---

**Note:** This is a demonstration project built for educational purposes. For production use, additional security measures, testing, and optimization would be required.
