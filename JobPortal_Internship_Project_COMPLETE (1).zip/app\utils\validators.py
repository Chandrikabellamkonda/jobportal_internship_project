import re
from typing import Any

def validate_email(email: str) -> bool:
    """Validate email format"""
    if not email:
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_password(password: str, min_length: int = 8) -> bool:
    """Validate password strength"""
    if not password or len(password) < min_length:
        return False
    
    # Check for at least one letter and one number
    has_letter = bool(re.search(r'[a-zA-Z]', password))
    has_number = bool(re.search(r'\d', password))
    
    return has_letter and has_number

def validate_user_input(input_value: Any, min_length: int = 1, max_length: int = 255) -> bool:
    """Validate general user input"""
    if not input_value or not isinstance(input_value, str):
        return False
    
    input_value = input_value.strip()
    
    if len(input_value) < min_length or len(input_value) > max_length:
        return False
    
    # Check for valid characters (alphanumeric, spaces, common punctuation)
    pattern = r'^[a-zA-Z0-9\s.,!?@#$%&*()_+-=:;<>\[\]{}|\\/"\'`~]+$'
    return bool(re.match(pattern, input_value))

def validate_phone_number(phone: str) -> bool:
    """Validate phone number format"""
    if not phone:
        return True  # Phone is optional
    
    # Remove all non-digit characters
    digits_only = re.sub(r'\D', '', phone)
    
    # Check if it's a valid length (7-15 digits)
    return 7 <= len(digits_only) <= 15

def validate_salary(salary: str) -> tuple[bool, int | None]:
    """Validate salary input and return (is_valid, salary_value)"""
    if not salary:
        return True, None
    
    try:
        salary_value = int(salary)
        if salary_value < 0:
            return False, None
        return True, salary_value
    except ValueError:
        return False, None

def sanitize_input(input_value: str) -> str:
    """Sanitize user input by removing potentially harmful characters"""
    if not input_value:
        return ""
    
    # Remove HTML tags
    import html
    sanitized = html.escape(input_value.strip())
    
    return sanitized
