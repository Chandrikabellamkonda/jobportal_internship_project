from app import create_app, db
from app.models import User

app = create_app()

@app.cli.command()
def create_admin():
    """Create an admin user"""
    email = input("Enter admin email: ")
    password = input("Enter admin password: ")
    full_name = input("Enter admin full name: ")
    
    # Check if admin already exists
    if User.query.filter_by(email=email).first():
        print("Admin user already exists!")
        return
    
    # Create admin user
    admin = User(
        email=email,
        full_name=full_name,
        user_type='admin'
    )
    admin.set_password(password)
    
    db.session.add(admin)
    db.session.commit()
    
    print("Admin user created successfully!")

@app.cli.command()
def init_db():
    """Initialize the database with sample data"""
    db.create_all()
    
    # Create sample users
    job_seeker = User(
        email='jobseeker@example.com',
        full_name='John Doe',
        user_type='job_seeker',
        location='New York, NY',
        phone='+1-555-0123'
    )
    job_seeker.set_password('password123')
    
    employer = User(
        email='employer@example.com',
        full_name='Jane Smith',
        user_type='employer',
        company_name='Tech Corp',
        location='San Francisco, CA',
        phone='+1-555-0456'
    )
    employer.set_password('password123')
    
    db.session.add(job_seeker)
    db.session.add(employer)
    db.session.commit()
    
    print("Sample data created successfully!")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
