from app import db, bcrypt
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy import func

class User(UserMixin, db.Model):
    """User model for job seekers, employers, and admins"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(128), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    user_type = db.Column(db.Enum('job_seeker', 'employer', 'admin', name='user_types'), nullable=False)
    company_name = db.Column(db.String(100), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    location = db.Column(db.String(100), nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    jobs_posted = db.relationship('Job', backref='employer', lazy='dynamic', cascade='all, delete-orphan')
    applications = db.relationship('Application', backref='applicant', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.email}>'
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
    
    def check_password(self, password):
        """Check if provided password matches hash"""
        return bcrypt.check_password_hash(self.password_hash, password)
    
    @property
    def is_employer(self):
        return self.user_type == 'employer'
    
    @property
    def is_job_seeker(self):
        return self.user_type == 'job_seeker'
    
    @property
    def is_admin(self):
        return self.user_type == 'admin'
    
    # Flask-Login compatibility - ensure is_active property works correctly
    def get_id(self):
        """Return user ID for Flask-Login"""
        return str(self.id)


class Job(db.Model):
    """Job model for storing job postings"""
    __tablename__ = 'jobs'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    company_name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    salary_min = db.Column(db.Integer, nullable=True)
    salary_max = db.Column(db.Integer, nullable=True)
    job_type = db.Column(db.Enum('full_time', 'part_time', 'contract', 'internship', name='job_types'), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    requirements = db.Column(db.Text, nullable=True)
    benefits = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign key
    employer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    applications = db.relationship('Application', backref='job', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Job {self.title} at {self.company_name}>'
    
    @property
    def salary_range(self):
        """Return formatted salary range"""
        if self.salary_min and self.salary_max:
            return f"${self.salary_min:,} - ${self.salary_max:,}"
        elif self.salary_min:
            return f"${self.salary_min:,}+"
        elif self.salary_max:
            return f"Up to ${self.salary_max:,}"
        else:
            return "Salary not specified"
    
    @property
    def application_count(self):
        """Return number of applications for this job"""
        return self.applications.count()
    
    @property
    def days_since_posted(self):
        """Return days since job was posted"""
        return (datetime.utcnow() - self.created_at).days
    
    @staticmethod
    def search_jobs(query, location=None, category=None, job_type=None):
        """Search jobs with filters"""
        jobs = Job.query.filter(Job.is_active == True)
        
        if query:
            jobs = jobs.filter(
                db.or_(
                    Job.title.contains(query),
                    Job.description.contains(query),
                    Job.company_name.contains(query)
                )
            )
        
        if location:
            jobs = jobs.filter(Job.location.contains(location))
        
        if category:
            jobs = jobs.filter(Job.category == category)
        
        if job_type:
            jobs = jobs.filter(Job.job_type == job_type)
        
        return jobs.order_by(Job.created_at.desc())


class Application(db.Model):
    """Application model for job applications"""
    __tablename__ = 'applications'
    
    id = db.Column(db.Integer, primary_key=True)
    cover_letter = db.Column(db.Text, nullable=True)
    resume_filename = db.Column(db.String(255), nullable=True)
    status = db.Column(db.Enum('pending', 'reviewed', 'accepted', 'rejected', name='application_status'), default='pending')
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    
    # Foreign keys
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'), nullable=False)
    applicant_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        return f'<Application {self.applicant.full_name} for {self.job.title}>'
    
    @property
    def days_since_applied(self):
        """Return days since application was submitted"""
        return (datetime.utcnow() - self.applied_at).days
