from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app, send_from_directory
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import os
import uuid
from app import db
from app.models import Job, Application, User
from app.utils.validators import validate_user_input

jobs_bp = Blueprint('jobs', __name__)

# Configuration for file uploads
UPLOAD_FOLDER = 'uploads/resumes'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_resume(file, user_id, job_id):
    """Save uploaded resume file"""
    if file and allowed_file(file.filename):
        # Create unique filename
        file_extension = file.filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{user_id}_{job_id}_{uuid.uuid4().hex}.{file_extension}"
        
        # Create upload directory if it doesn't exist
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        
        # Save file
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)
        
        return unique_filename
    return None

@jobs_bp.route('/')
@login_required
def my_jobs():
    """Employer's job listings"""
    if not current_user.is_employer:
        flash('Access denied. Employer privileges required.', 'error')
        return redirect(url_for('main.home'))
    
    jobs = Job.query.filter_by(employer_id=current_user.id).order_by(Job.created_at.desc()).all()
    return render_template('jobs/my_jobs.html', jobs=jobs)

@jobs_bp.route('/post', methods=['GET', 'POST'])
@login_required
def post_job():
    """Post a new job"""
    if not current_user.is_employer:
        flash('Access denied. Employer privileges required.', 'error')
        return redirect(url_for('main.home'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        company_name = request.form.get('company_name', '').strip()
        location = request.form.get('location', '').strip()
        salary_min = request.form.get('salary_min', '').strip()
        salary_max = request.form.get('salary_max', '').strip()
        job_type = request.form.get('job_type', '').strip()
        category = request.form.get('category', '').strip()
        requirements = request.form.get('requirements', '').strip()
        benefits = request.form.get('benefits', '').strip()
        
        # Validation
        errors = []
        
        if not validate_user_input(title, min_length=5):
            errors.append('Job title must be at least 5 characters long.')
        
        if not validate_user_input(description, min_length=20, max_length=5000):
            errors.append('Job description must be at least 20 characters long and no more than 5000 characters.')
        
        if not validate_user_input(company_name, min_length=2):
            errors.append('Company name is required.')
        
        if not validate_user_input(location, min_length=2):
            errors.append('Location is required.')
        
        if job_type not in ['full_time', 'part_time', 'contract', 'internship']:
            errors.append('Please select a valid job type.')
        
        if not validate_user_input(category, min_length=2):
            errors.append('Job category is required.')
        
        # Validate salary if provided
        if salary_min:
            try:
                salary_min = int(salary_min)
                if salary_min < 0:
                    errors.append('Minimum salary cannot be negative.')
            except ValueError:
                errors.append('Invalid minimum salary format.')
        else:
            salary_min = None
        
        if salary_max:
            try:
                salary_max = int(salary_max)
                if salary_max < 0:
                    errors.append('Maximum salary cannot be negative.')
            except ValueError:
                errors.append('Invalid maximum salary format.')
        else:
            salary_max = None
        
        if salary_min and salary_max and salary_min > salary_max:
            errors.append('Minimum salary cannot be greater than maximum salary.')
        
        if errors:
            for error in errors:
                flash(error, 'error')
        else:
            try:
                job = Job(
                    title=title,
                    description=description,
                    company_name=company_name,
                    location=location,
                    salary_min=salary_min,
                    salary_max=salary_max,
                    job_type=job_type,
                    category=category,
                    requirements=requirements,
                    benefits=benefits,
                    employer_id=current_user.id
                )
                
                db.session.add(job)
                db.session.commit()
                
                flash('Job posted successfully!', 'success')
                return redirect(url_for('jobs.my_jobs'))
                
            except Exception as e:
                db.session.rollback()
                flash('An error occurred while posting the job. Please try again.', 'error')
    
    # Get available categories
    categories = ['Technology', 'Healthcare', 'Finance', 'Education', 'Marketing', 'Sales', 'Design', 'Engineering', 'Customer Service', 'Other']
    job_types = ['full_time', 'part_time', 'contract', 'internship']
    
    return render_template('jobs/post_job.html', categories=categories, job_types=job_types)

@jobs_bp.route('/edit/<int:job_id>', methods=['GET', 'POST'])
@login_required
def edit_job(job_id):
    """Edit a job posting"""
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id and not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    if request.method == 'POST':
        job.title = request.form.get('title', '').strip()
        job.description = request.form.get('description', '').strip()
        job.company_name = request.form.get('company_name', '').strip()
        job.location = request.form.get('location', '').strip()
        job.job_type = request.form.get('job_type', '').strip()
        job.category = request.form.get('category', '').strip()
        job.requirements = request.form.get('requirements', '').strip()
        job.benefits = request.form.get('benefits', '').strip()
        
        # Handle salary fields
        salary_min = request.form.get('salary_min', '').strip()
        salary_max = request.form.get('salary_max', '').strip()
        
        job.salary_min = int(salary_min) if salary_min else None
        job.salary_max = int(salary_max) if salary_max else None
        
        try:
            db.session.commit()
            flash('Job updated successfully!', 'success')
            return redirect(url_for('jobs.my_jobs'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while updating the job.', 'error')
    
    categories = ['Technology', 'Healthcare', 'Finance', 'Education', 'Marketing', 'Sales', 'Design', 'Engineering', 'Customer Service', 'Other']
    job_types = ['full_time', 'part_time', 'contract', 'internship']
    
    return render_template('jobs/edit_job.html', job=job, categories=categories, job_types=job_types)

@jobs_bp.route('/delete/<int:job_id>')
@login_required
def delete_job(job_id):
    """Delete a job posting"""
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id and not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    try:
        db.session.delete(job)
        db.session.commit()
        flash('Job deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while deleting the job.', 'error')
    
    return redirect(url_for('jobs.my_jobs'))

@jobs_bp.route('/toggle/<int:job_id>')
@login_required
def toggle_job_status(job_id):
    """Toggle job active status"""
    job = Job.query.get_or_404(job_id)
    
    if job.employer_id != current_user.id and not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    job.is_active = not job.is_active
    status = "activated" if job.is_active else "deactivated"
    
    try:
        db.session.commit()
        flash(f'Job {status} successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while updating the job status.', 'error')
    
    return redirect(url_for('jobs.my_jobs'))

@jobs_bp.route('/apply/<int:job_id>', methods=['GET', 'POST'])
@login_required
def apply_job(job_id):
    """Apply for a job"""
    if not current_user.is_job_seeker:
        flash('Only job seekers can apply for jobs.', 'error')
        return redirect(url_for('main.home'))
    
    job = Job.query.get_or_404(job_id)
    
    if not job.is_active:
        flash('This job is no longer available.', 'error')
        return redirect(url_for('main.home'))
    
    # Check if user already applied
    existing_application = Application.query.filter_by(
        job_id=job_id, 
        applicant_id=current_user.id
    ).first()
    
    if existing_application:
        flash('You have already applied for this job.', 'info')
        return redirect(url_for('main.job_detail', job_id=job_id))
    
    if request.method == 'POST':
        cover_letter = request.form.get('cover_letter', '').strip()
        resume_file = request.files.get('resume')
        
        # Validate cover letter
        if not cover_letter or len(cover_letter.strip()) < 10:
            flash('Please provide a cover letter (at least 10 characters).', 'error')
            return render_template('jobs/apply_job.html', job=job)
        
        # Validate resume file
        if not resume_file or resume_file.filename == '':
            flash('Please upload your resume.', 'error')
            return render_template('jobs/apply_job.html', job=job)
        
        # Check file size
        resume_file.seek(0, 2)  # Seek to end
        file_size = resume_file.tell()
        resume_file.seek(0)  # Reset to beginning
        
        if file_size > MAX_FILE_SIZE:
            flash('Resume file is too large. Maximum size is 5MB.', 'error')
            return render_template('jobs/apply_job.html', job=job)
        
        # Check file extension
        if not allowed_file(resume_file.filename):
            flash('Invalid file format. Please upload a PDF, DOC, or DOCX file.', 'error')
            return render_template('jobs/apply_job.html', job=job)
        
        try:
            # Save resume file
            resume_filename = save_resume(resume_file, current_user.id, job_id)
            
            if not resume_filename:
                flash('Error saving resume file. Please try again.', 'error')
                return render_template('jobs/apply_job.html', job=job)
            
            # Create application
            application = Application(
                job_id=job_id,
                applicant_id=current_user.id,
                cover_letter=cover_letter,
                resume_filename=resume_filename
            )
            
            db.session.add(application)
            db.session.commit()
            
            flash('Application submitted successfully!', 'success')
            return redirect(url_for('jobs.my_applications'))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error submitting application: {e}")
            flash('An error occurred while submitting your application.', 'error')
    
    return render_template('jobs/apply_job.html', job=job)

@jobs_bp.route('/applications')
@login_required
def my_applications():
    """User's job applications"""
    if current_user.is_job_seeker:
        applications = Application.query.filter_by(applicant_id=current_user.id).order_by(Application.applied_at.desc()).all()
        return render_template('jobs/my_applications.html', applications=applications)
    elif current_user.is_employer:
        # Get applications for jobs posted by this employer
        applications = Application.query.join(Job).filter(Job.employer_id == current_user.id).order_by(Application.applied_at.desc()).all()
        return render_template('jobs/employer_applications.html', applications=applications)
    else:
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))

@jobs_bp.route('/application/<int:application_id>/update-status', methods=['POST'])
@login_required
def update_application_status(application_id):
    """Update application status (for employers and admins)"""
    application = Application.query.get_or_404(application_id)
    
    # Check permissions - allow employers and admins
    if not (current_user.is_admin or 
            (current_user.is_employer and application.job.employer_id == current_user.id)):
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    new_status = request.form.get('status', '').strip()
    
    if new_status in ['pending', 'reviewed', 'accepted', 'rejected']:
        application.status = new_status
        if new_status != 'pending':
            from datetime import datetime
            application.reviewed_at = datetime.utcnow()
        
        try:
            db.session.commit()
            flash('Application status updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating application status: {e}")
            flash('An error occurred while updating the application status.', 'error')
    
    # Redirect back to the appropriate page
    # Check if we came from a specific page and redirect accordingly
    referer = request.referrer
    if referer:
        if '/application/' in referer and str(application_id) in referer:
            # Came from detailed application view
            return redirect(url_for('jobs.view_application_details', application_id=application_id))
        elif '/job/' in referer and '/applications' in referer:
            # Came from job-specific applications page
            return redirect(url_for('jobs.job_applications', job_id=application.job_id))
    
    # Default redirect to general applications page
    return redirect(url_for('jobs.my_applications'))

@jobs_bp.route('/application/<int:application_id>')
@login_required
def view_application_details(application_id):
    """View detailed application information (for employers and admins)"""
    application = Application.query.get_or_404(application_id)
    
    # Check if user has permission to view this application
    if not (current_user.is_admin or 
            (current_user.is_employer and application.job.employer_id == current_user.id)):
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    return render_template('jobs/application_details.html', application=application)

@jobs_bp.route('/job/<int:job_id>/applications')
@login_required
def job_applications(job_id):
    """View all applications for a specific job (for employers and admins)"""
    job = Job.query.get_or_404(job_id)
    
    # Check if user has permission to view applications for this job
    if not (current_user.is_admin or 
            (current_user.is_employer and job.employer_id == current_user.id)):
        flash('Access denied.', 'error')
        return redirect(url_for('main.home'))
    
    # Get all applications for this job
    applications = Application.query.filter_by(job_id=job_id).order_by(Application.applied_at.desc()).all()
    
    return render_template('jobs/job_applications.html', job=job, applications=applications)

@jobs_bp.route('/resume/<int:application_id>', methods=['GET'])
@login_required
def download_resume(application_id):
    """Download resume for an application"""
    try:
        current_app.logger.info(f"Download resume route called for application_id: {application_id}")
        
        # Try to get the application
        application = Application.query.get(application_id)
        if not application:
            current_app.logger.error(f"Application with ID {application_id} not found")
            flash('Application not found.', 'error')
            return redirect(url_for('jobs.my_applications'))
            
        current_app.logger.info(f"Application found: {application.id}, resume_filename: {application.resume_filename}")
        
        # Check if user has permission to view this resume
        if not (current_user.is_admin or 
                (current_user.is_employer and application.job.employer_id == current_user.id) or
                (current_user.is_job_seeker and application.applicant_id == current_user.id)):
            current_app.logger.error(f"Access denied for user {current_user.id} to application {application_id}")
            flash('Access denied.', 'error')
            return redirect(url_for('main.home'))
        
        if not application.resume_filename:
            current_app.logger.error(f"No resume filename for application {application_id}")
            flash('No resume available for this application.', 'error')
            return redirect(url_for('jobs.my_applications'))
        
        # Get absolute path to upload folder
        upload_path = os.path.abspath(UPLOAD_FOLDER)
        current_app.logger.info(f"Downloading resume: {application.resume_filename} from {upload_path}")
        
        # Check if file exists
        file_path = os.path.join(upload_path, application.resume_filename)
        if not os.path.exists(file_path):
            current_app.logger.error(f"File not found: {file_path}")
            flash('Resume file not found.', 'error')
            return redirect(url_for('jobs.my_applications'))
        
        return send_from_directory(upload_path, application.resume_filename, as_attachment=True)
        
    except Exception as e:
        current_app.logger.error(f"Error downloading resume: {e}")
        flash('Error downloading resume file.', 'error')
        return redirect(url_for('jobs.my_applications'))
