#!/usr/bin/env python3
"""
Script to create sample data for the Job Portal application
Run this script to populate the database with sample users and jobs
"""

from app import create_app, db
from app.models import User, Job, Application
from datetime import datetime

def create_sample_data():
    """Create sample data for testing"""
    app = create_app()
    
    with app.app_context():
        # Create sample job seeker
        job_seeker = User.query.filter_by(email='jobseeker@example.com').first()
        if not job_seeker:
            job_seeker = User(
                email='jobseeker@example.com',
                full_name='John Doe',
                user_type='job_seeker',
                location='New York, NY',
                phone='+1-555-0123'
            )
            job_seeker.set_password('password123')
            db.session.add(job_seeker)
            print("Created sample job seeker: jobseeker@example.com / password123")
        
        # Create sample employer
        employer = User.query.filter_by(email='employer@example.com').first()
        if not employer:
            employer = User(
                email='employer@example.com',
                full_name='Jane Smith',
                user_type='employer',
                company_name='Tech Corp',
                location='San Francisco, CA',
                phone='+1-555-0456'
            )
            employer.set_password('password123')
            db.session.add(employer)
            print("Created sample employer: employer@example.com / password123")
        
        # Create sample jobs
        sample_jobs = [
            {
                'title': 'Senior Software Engineer',
                'description': 'We are looking for an experienced software engineer to join our team. You will be responsible for developing and maintaining our web applications using modern technologies.',
                'company_name': 'Tech Corp',
                'location': 'San Francisco, CA',
                'salary_min': 120000,
                'salary_max': 180000,
                'job_type': 'full_time',
                'category': 'Technology',
                'requirements': 'Bachelor\'s degree in Computer Science or related field. 5+ years of experience with Python, JavaScript, and web frameworks.',
                'benefits': 'Health insurance, 401k, flexible work hours, remote work options'
            },
            {
                'title': 'Marketing Manager',
                'description': 'Join our marketing team to develop and execute marketing strategies. You will work with cross-functional teams to drive brand awareness and customer acquisition.',
                'company_name': 'Tech Corp',
                'location': 'New York, NY',
                'salary_min': 80000,
                'salary_max': 120000,
                'job_type': 'full_time',
                'category': 'Marketing',
                'requirements': 'Bachelor\'s degree in Marketing or related field. 3+ years of marketing experience. Strong communication skills.',
                'benefits': 'Health insurance, dental, vision, paid time off, professional development budget'
            },
            {
                'title': 'Data Analyst Intern',
                'description': 'Great opportunity for students to gain hands-on experience in data analysis. You will work with our data team to analyze business metrics and create reports.',
                'company_name': 'Tech Corp',
                'location': 'Remote',
                'salary_min': 20,
                'salary_max': 25,
                'job_type': 'internship',
                'category': 'Technology',
                'requirements': 'Currently enrolled in a Bachelor\'s program. Basic knowledge of SQL and Excel. Strong analytical skills.',
                'benefits': 'Mentorship program, flexible schedule, potential full-time offer'
            }
        ]
        
        for job_data in sample_jobs:
            existing_job = Job.query.filter_by(
                title=job_data['title'],
                company_name=job_data['company_name']
            ).first()
            
            if not existing_job:
                job = Job(
                    title=job_data['title'],
                    description=job_data['description'],
                    company_name=job_data['company_name'],
                    location=job_data['location'],
                    salary_min=job_data['salary_min'],
                    salary_max=job_data['salary_max'],
                    job_type=job_data['job_type'],
                    category=job_data['category'],
                    requirements=job_data['requirements'],
                    benefits=job_data['benefits'],
                    employer_id=employer.id
                )
                db.session.add(job)
                print(f"Created sample job: {job_data['title']}")
        
        # Commit all changes
        db.session.commit()
        print("\nSample data created successfully!")
        print("\nDefault accounts:")
        print("Admin: admin@jobportal.com / admin123")
        print("Job Seeker: jobseeker@example.com / password123")
        print("Employer: employer@example.com / password123")

if __name__ == '__main__':
    create_sample_data()
