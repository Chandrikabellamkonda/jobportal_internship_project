# Job Portal Web Application - Setup Instructions

## Quick Start Guide

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Installation Steps

1. **Extract the Project**
   ```bash
   # Extract the JobPortal_Internship_Project.zip file
   ```

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Create Sample Data (Optional)**
   ```bash
   python create_sample_data.py
   ```

4. **Run the Application**
   ```bash
   python run.py
   ```

5. **Access the Application**
   - Open your browser and go to: `http://127.0.0.1:5000`

### Default Login Credentials

**Admin Account:**
- Email: `admin@jobportal.com`
- Password: `admin123`

**Job Seeker Account:**
- Email: `jobseeker@example.com`
- Password: `password123`

**Employer Account:**
- Email: `employer@example.com`
- Password: `password123`

### Key Features to Test

1. **User Registration & Login**
   - Register as Job Seeker or Employer
   - Test login functionality

2. **Job Management (Employers)**
   - Post new job listings
   - Edit existing jobs
   - View applications received

3. **Job Application (Job Seekers)**
   - Search and browse jobs
   - Apply for jobs with resume upload
   - Track application status

4. **Admin Panel**
   - User management (activate/deactivate users)
   - Job management
   - Application overview
   - System statistics

### Technical Highlights

- **Security**: Password hashing with bcrypt, input validation, file upload security
- **Database**: SQLite with SQLAlchemy ORM, proper relationships and constraints
- **File Management**: Resume upload system with access control
- **User Roles**: Three-tier user system (Job Seeker, Employer, Admin)
- **Responsive Design**: Bootstrap-based UI with mobile support

### Project Structure
```
app/
├── models.py          # Database models
├── routes/           # Application routes
├── templates/        # HTML templates
├── static/          # CSS and JavaScript
└── utils/           # Validation utilities
```

For detailed technical documentation, see `TECHNICAL_DOCUMENTATION.md`
