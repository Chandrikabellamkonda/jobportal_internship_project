from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app import db, bcrypt
from app.models import User
from app.utils.validators import validate_email, validate_password, validate_user_input
import logging

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        full_name = request.form.get('full_name', '').strip()
        user_type = request.form.get('user_type', '')
        company_name = request.form.get('company_name', '').strip()
        phone = request.form.get('phone', '').strip()
        location = request.form.get('location', '').strip()
        
        # Validation
        errors = []
        
        if not validate_email(email):
            errors.append('Please enter a valid email address.')
        
        if not validate_password(password):
            errors.append('Password must be at least 8 characters long.')
        
        if password != confirm_password:
            errors.append('Passwords do not match.')
        
        if not validate_user_input(full_name, min_length=2):
            errors.append('Please enter a valid full name.')
        
        if user_type not in ['job_seeker', 'employer']:
            errors.append('Please select a valid user type.')
        
        if user_type == 'employer' and not validate_user_input(company_name, min_length=2):
            errors.append('Company name is required for employers.')
        
        # Check if email already exists
        if User.query.filter_by(email=email).first():
            errors.append('Email address is already registered.')
        
        if errors:
            for error in errors:
                flash(error, 'error')
        else:
            try:
                # Create new user
                user = User(
                    email=email,
                    full_name=full_name,
                    user_type=user_type,
                    company_name=company_name if user_type == 'employer' else None,
                    phone=phone,
                    location=location
                )
                user.set_password(password)
                
                db.session.add(user)
                db.session.commit()
                
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('auth.login'))
                
            except Exception as e:
                current_app.logger.error(f"Registration error: {str(e)}")
                db.session.rollback()
                flash('An error occurred during registration. Please try again.', 'error')
    
    return render_template('auth/register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    
    if request.method == 'POST':
        # Get form data
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember = bool(request.form.get('remember'))
        
        # Validation
        if not email or not password:
            flash('Please enter both email and password.', 'error')
            return render_template('auth/login.html')
        
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Check if user account is active
            user_is_active = getattr(user, 'is_active', True)  # Default to True if field doesn't exist
            if not user_is_active:
                current_app.logger.warning(f"Login attempt by inactive user: {email}")
                flash('❌ Your account has been deactivated and cannot be accessed. Please contact an administrator for assistance.', 'error')
                return render_template('auth/login.html')
            
            if user.check_password(password):
                try:
                    login_user(user, remember=remember)
                except Exception as e:
                    current_app.logger.error(f"Error during login: {e}")
                    flash('An error occurred during login. Please try again.', 'error')
                    return render_template('auth/login.html')
                
                # Determine redirect URL
                next_page = request.args.get('next')
                if next_page:
                    redirect_url = next_page
                elif user.is_admin:
                    redirect_url = url_for('admin.dashboard')
                elif user.is_employer:
                    redirect_url = url_for('jobs.my_jobs')
                else:
                    redirect_url = url_for('main.home')
                
                return redirect(redirect_url)
            else:
                flash('Invalid email or password.', 'error')
        else:
            flash('Invalid email or password.', 'error')
    
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('main.home'))

@auth_bp.route('/profile')
@login_required
def profile():
    """User profile page"""
    return render_template('auth/profile.html', user=current_user)
